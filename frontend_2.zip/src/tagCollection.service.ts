import { Injectable } from '@angular/core';
import { Tag } from './tag';

@Injectable({
  providedIn: 'root',
})
export class TagCollection {
  tags: Tag[];

  constructor() {}
  addTag(tag: Tag) {
    this.tags.push(tag);
  }

  getTag() {
    return this.tags;
  }
}
