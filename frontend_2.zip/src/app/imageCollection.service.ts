import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Image } from './image';

@Injectable({
  providedIn: 'root',
})
export class Collection {
  images: Image[] = [];

  addImage(image: Image) {
    this.images.push(image);
  }

  getImages() {
    return this.images;
  }
}
