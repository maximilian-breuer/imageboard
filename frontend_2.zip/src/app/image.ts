
export interface Image {
  source: any; 
  tags: string[];
  caption: string;


}
