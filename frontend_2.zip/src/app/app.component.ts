import { Component } from '@angular/core';
import { Image } from './image';
import { Collection } from './imageCollection.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  images: Image[];
  source: any; //oder URL

  tags: string[];
  caption: string;

  constructor(private collection: Collection) {
    this.images = this.collection.getImages();
  }

  addImage() {
    const newImage: Image = {
      source: this.source,
      tags: this.tags,
      caption: this.caption,
    };
    this.collection.addImage(newImage);
  }

}

